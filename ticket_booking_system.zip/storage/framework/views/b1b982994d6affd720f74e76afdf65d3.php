<?php $__env->startSection('title'); ?>
    Product
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main class="content px-4 py-3 mb-5">
    <div>
        <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('admin#purchaseList')); ?>">List</a></li>
              <li class="breadcrumb-item active" aria-current="page">View</li>
            </ol>
        </nav>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10 offset-md-1">
                <div class="shadow p-2 border-0 shadow">
                    <h4 class="text-center py-2 mb-4">View Purchase</h4>
                    <div class="row">
                        <div class="col-md-4">
                            <img src="<?php echo e(Storage::url('product/'.$purchase->product_image)); ?>" class="w-100 img-thumbnail" alt="">
                        </div>
                        <div class="col-md-8">
                            <div class="py-2">
                                <h5>Product Name - <?php echo e($purchase->product_name); ?></h5>
                            </div>
                            <div class="py-2">
                                <h5>Product QTY - <?php echo e($purchase->qty); ?></h5>
                            </div>
                            <div class="py-2">
                                <h5>Product Price - <?php echo e($purchase->price); ?> MMK</h5>
                            </div>
                            <div class="py-2">
                                <h5>Total Price - <?php echo e($purchase->total_price); ?> MMK</h5>
                            </div>
                            <div class="py-2">
                                <h5>Supplier Name - <?php echo e($purchase->supplier_name); ?></h5>
                            </div>
                            <div class="py-2">
                                <h5>Store Name - <?php echo e($purchase->store_name); ?></h5>
                            </div>
                            <div class="py-2">
                                <h5>Date - <?php echo e($purchase->created_at); ?></h5>
                            </div>
                            <div class="py-2">
                                <h5>Status - <?php if($purchase->status==0): ?>
                                    <span class="text-warning">Pending</span>
                                <?php elseif($purchase->status==1): ?>
                                    <span class="text-success">Success</span>
                                <?php else: ?>
                                    <span class="text-danger">Reject</span>
                                <?php endif; ?></h5>
                            </div>
                            <div class="py-2 d-flex justify-content-end gap-1">
                                <?php if(Auth::user()->purchase): ?>
                                    <div>
                                        <div class="dropdown">
                                            <button class="btn <?php if($purchase->status==0): ?> btn-warning  <?php elseif($purchase->status==1): ?> btn-success <?php elseif($purchase->status==2): ?> btn-danger <?php endif; ?> dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            <?php if($purchase->status==0): ?>
                                                Pending
                                            <?php elseif($purchase->status==1): ?>
                                                Success
                                            <?php elseif($purchase->status==2): ?>
                                                Reject
                                            <?php endif; ?>
                                            </button>
                                            <ul class="dropdown-menu">
                                            <li><a class="dropdown-item" href="<?php echo e(route('admin#purchaseChangeStatus',[$purchase->id,0])); ?>">Pending</a></li>
                                            <li><a class="dropdown-item" href="<?php echo e(route('admin#purchaseChangeStatus',[$purchase->id,1])); ?>">Success</a></li>
                                            <li><a class="dropdown-item" href="<?php echo e(route('admin#purchaseChangeStatus',[$purchase->id,2])); ?>">Reject</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <?php if($purchase->status==0): ?>
                                        <button type="button" class="btn btn-primary me-2" data-bs-toggle="modal" data-bs-target="#edit-purchase">Edit</button>
                                    <?php endif; ?>
                                    <?php if($purchase->status!=1): ?>
                                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#delete-product">Delete</button>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <button class="btn <?php if($purchase->status==0): ?> btn-warning  <?php elseif($purchase->status==1): ?> btn-success <?php elseif($purchase->status==2): ?> btn-danger <?php endif; ?>" type="button">
                                        <?php if($purchase->status==0): ?>
                                            Pending
                                        <?php elseif($purchase->status==1): ?>
                                            Success
                                        <?php elseif($purchase->status==2): ?>
                                            Reject
                                        <?php endif; ?>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php if($purchase->status==0): ?>
            <div class="modal fade" id="edit-purchase" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="edit-purchaseLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title d-block w-100 text-center" id="edit-purchaseLabel">Edit Purchase</h4>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('admin#purchaseUpdate')); ?>" method="post" class="mt-1">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <div class="form-group mb-4">
                                    <label class="mb-1">Product</label>
                                    <select name="product" id="" class="form-control <?php $__errorArgs = ['product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="">Choose Product</option>
                                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e(json_encode(['id'=>$item->id,'name'=>$item->name])); ?>" <?php if($item->name==$purchase->product_name): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group mb-4">
                                    <label class="mb-1">Supplier</label>
                                    <select name="supplier_id" id="" class="form-control <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="">Choose Supplier</option>
                                        <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php if($item->id==$purchase->supplier_id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group mb-4">
                                    <label class="mb-1">Store</label>
                                    <select name="store_id" id="" class="form-control <?php $__errorArgs = ['store_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="">Choose Store</option>
                                        <?php $__currentLoopData = $store; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php if($item->id==$purchase->store_id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['store_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group mb-4">
                                    <label class="mb-1">Qty</label>
                                    <input id="" name="qty" type="number" value="<?php echo e($purchase->qty); ?>" class="form-control <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter product qty">
                                    <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group mb-4">
                                    <label class="mb-1">Price (For one item)</label>
                                    <input id="" name="price" type="number" value="<?php echo e($purchase->price); ?>" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter product price">
                                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <input type="hidden" name="id" value="<?php echo e($purchase->id); ?>">

                                <button type="submit" class="btn btn-primary w-100 my-2">Update</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if($purchase->status!=1): ?>
            <div class="modal fade" id="delete-product" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="delete-productLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title d-block w-100 text-center text-danger" id="delete-productLabel">Delete Purchase</h4>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('admin#purchaseDelete')); ?>" method="post" class="mt-1">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <div class="py-1">
                                    <p class="text-danger">"Are you sure to delete this."</p>
                                </div>
                                <div class="py-1">
                                    <h6>Verify you are admin. Please enter the password.</h6>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="mb-1">Password</label>
                                    <input id="" name="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter your password." required>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <input type="hidden" name="id" value="<?php echo e($purchase->id); ?>">

                                <button type="submit" class="btn btn-danger w-100 my-2">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.admin.layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Main Project\TicketBookingSystem\ticket_booking_system\resources\views/main/admin/purchase/view.blade.php ENDPATH**/ ?>