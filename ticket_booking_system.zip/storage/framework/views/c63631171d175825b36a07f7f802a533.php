<?php $__env->startSection('title'); ?>
    Purchase
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main class="content px-4 py-4 mb-5">
    <div class="row p-4 mb-4">
        <?php $__currentLoopData = $summary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 py-2">
                <div class="shadow rounded p-4">
                    <h5 class=" py-1">Total <?php if($item->status==0): ?> Pending <?php elseif($item->status==1): ?> Success <?php else: ?> Reject <?php endif; ?> Purchase Count</h5>
                    <div class="d-flex align-items-center gap-1">
                        <div class="shadow py-2 px-2 bg-primary rounded-circle d-flex align-items-center justify-content-center">
                            <i class="fa-solid fa-ticket fs-2 text-white"></i>
                        </div>
                        <h5 class="py-2"><?php echo e($item->total_count); ?></h5>
                    </div>
                </div>
            </div>
            <div class="col-md-6 py-2">
                <div class="shadow rounded p-4">
                    <h5 class=" py-1">Total <?php if($item->status==0): ?> Pending <?php elseif($item->status==1): ?> Success <?php else: ?> Reject <?php endif; ?> Purchase Price</h5>
                    <div class="d-flex align-items-center gap-1">
                        <div class="shadow py-2 px-3 bg-primary rounded-circle d-flex align-items-center justify-content-center">
                            <i class="fa-solid fa-dollar-sign fs-2 text-white"></i>
                        </div>
                        <h5 class="py-2"><?php echo e(number_format($item->total_price)); ?></h5>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="d-flex align-items-center justify-content-between">
        <div class="bg-white text-dark px-3 border rounded pt-2 h-100 text-center">
            <h5>Total - <?php echo e($purchase->total()); ?></h5>
        </div>
        <form action="" id="search-form">
            <div class="search-cinema">
                <svg class="icon" aria-hidden="true" viewBox="0 0 24 24"><g><path d="M21.53 20.47l-3.66-3.66C19.195 15.24 20 13.214 20 11c0-4.97-4.03-9-9-9s-9 4.03-9 9 4.03 9 9 9c2.215 0 4.24-.804 5.808-2.13l3.66 3.66c.147.146.34.22.53.22s.385-.073.53-.22c.295-.293.295-.767.002-1.06zM3.5 11c0-4.135 3.365-7.5 7.5-7.5s7.5 3.365 7.5 7.5-3.365 7.5-7.5 7.5-7.5-3.365-7.5-7.5z"></path></g></svg>
                <input placeholder="Search" type="search" name="search_key" value="<?php echo e(request('search_key')); ?>" class="input" placeholder="Enter purchase ID">
            </div>
        </form>
        <div class="form-group">
            <?php if(Auth::user()->purchase): ?>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#create-purchase">Create Purchase</button>
            <?php endif; ?>
        </div>
    </div>
    <form action="" id="search-form-small" class="mb-3">
        <div class="search-cinema">
            <svg class="icon" aria-hidden="true" viewBox="0 0 24 24"><g><path d="M21.53 20.47l-3.66-3.66C19.195 15.24 20 13.214 20 11c0-4.97-4.03-9-9-9s-9 4.03-9 9 4.03 9 9 9c2.215 0 4.24-.804 5.808-2.13l3.66 3.66c.147.146.34.22.53.22s.385-.073.53-.22c.295-.293.295-.767.002-1.06zM3.5 11c0-4.135 3.365-7.5 7.5-7.5s7.5 3.365 7.5 7.5-3.365 7.5-7.5 7.5-7.5-3.365-7.5-7.5z"></path></g></svg>
            <input placeholder="Search" type="search" name="search_key" value="<?php echo e(request('search_key')); ?>" class="input" placeholder="Enter purchase ID">
        </div>
    </form>
    <form method="get" action="" class="mt-2 bg-body-secondary rounded px-2">
        <div class="py-2 d-flex gap-1 flex-wrap py-2">
            <div>
                <select name="status" class="form-control" style="font-size: 11pt;">
                    <option value="">Filter By Purchase Stauts</option>
                    <option value="">All</option>
                    <option value="0" <?php if(request('status')==='0'): ?> selected <?php endif; ?>>Pending</option>
                    <option value="1" <?php if(request('status')==1): ?> selected <?php endif; ?>>Success</option>
                    <option value="2" <?php if(request('status')==2): ?> selected <?php endif; ?>>Reject</option>
                </select>
            </div>
            <div>
                <select name="product_name" class="form-control" style="font-size: 11pt;">
                    <option value="">Filter By Product</option>
                    <option value="">All</option>
                    <?php $__currentLoopData = $productFilter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item); ?>" <?php if(request('product_name')===$item): ?> selected <?php endif; ?>><?php echo e($item); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="d-flex align-items-center justify-content-between flex-wrap mt-1">
            <div class="d-flex gap-1 flex-wrap py-2">
                <div>
                    <label for="" style="font-size: 11pt;">Start Date</label>
                    <input type="date" style="font-size: 11pt;" name="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
                </div>
                <div>
                    <label for="" style="font-size: 11pt;">End Date</label>
                    <input type="date" style="font-size: 11pt;" name="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
                </div>
            </div>
            <div class="d-flex align-items-center justify-content-end w-100 mb-2">
                <button class="btn btn-primary me-2" style="font-size: 11pt;">Filter</button>
                <a href="<?php echo e(route('admin#purchaseList')); ?>" style="font-size: 11pt;" class="btn btn-danger">Clear</a>
            </div>
        </div>
    </form>
    <div class="">
        <div id="table-bg">
            <div class="">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>QTY</th>
                                <th>Total Price</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $purchase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>PID - <?php echo e($item->id); ?></td>
                                <td><?php echo e($item->product_name); ?></td>
                                <td><?php echo e($item->qty); ?></td>
                                <td><?php echo e($item->total_price); ?> MMK</td>
                                <td><?php echo e($item->created_at); ?></td>
                                <td>
                                    <?php if($item->status==0): ?>
                                        <span class="text-warning">Pending</span>
                                    <?php elseif($item->status==1): ?>
                                        <span class="text-success">Success</span>
                                    <?php else: ?>
                                        <span class="text-danger">Reject</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin#purchaseView',$item->id)); ?>" class="btn btn-outline-primary">View</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div>
                        <?php echo e($purchase->appends(request()->query())->links()); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="create-purchase" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="create-purchaseLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title d-block w-100 text-center" id="create-purchaseLabel">Create Purchase</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('admin#purchaseCreate')); ?>" method="post" class="mt-1">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-4">
                                <label class="mb-1">Product</label>
                                <select name="product" id="" class="form-control <?php $__errorArgs = ['product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e(json_encode(['id'=>$item->id,'name'=>$item->name])); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group mb-4">
                                <label class="mb-1">Supplier</label>
                                <select name="supplier_id" id="" class="form-control <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="">Choose Supplier</option>
                                    <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group mb-4">
                                <label class="mb-1">Store</label>
                                <select name="store_id" id="" class="form-control <?php $__errorArgs = ['store_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="">Choose Store</option>
                                    <?php $__currentLoopData = $store; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['store_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group mb-4">
                                <label class="mb-1">Qty</label>
                                <input id="" name="qty" type="number" class="form-control <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter product qty">
                                <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group mb-4">
                                <label class="mb-1">Price (For one item)</label>
                                <input id="" name="price" type="number" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter product price">
                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button type="submit" class="btn btn-primary w-100 my-2">Add</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.admin.layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Main Project\TicketBookingSystem\ticket_booking_system\resources\views/main/admin/purchase/list.blade.php ENDPATH**/ ?>