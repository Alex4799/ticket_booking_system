<?php $__env->startSection('title'); ?>
    Product
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main class="content px-4 py-3 mb-5">
    <div>
        <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('admin#inventoryList')); ?>">List</a></li>
              <li class="breadcrumb-item active" aria-current="page">View</li>
            </ol>
        </nav>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10 offset-md-1">
                <div class="card p-2 border-0 shadow">
                    <h4 class="text-center py-2 mb-4">View Purchase</h4>
                    <div class="row">
                        <div class="col-md-4">
                            <img src="<?php echo e(Storage::url('product/'.$inventory->product_image)); ?>" class="w-100 img-thumbnail" alt="">
                        </div>
                        <div class="col-md-8">
                            <div class="py-2">
                                <h5>Product Name - <?php echo e($inventory->product_name); ?></h5>
                            </div>
                            <div class="py-2">
                                <h5>Product QTY - <?php echo e($inventory->qty); ?></h5>
                            </div>
                            <div class="py-2">
                                <h5>Product Price - <?php echo e($inventory->price); ?> MMK</h5>
                            </div>
                            <div class="py-2">
                                <h5>Total Price - <?php echo e($inventory->total_price); ?> MMK</h5>
                            </div>
                            <div class="py-2">
                                <h5>Send Store - <?php echo e($inventory->send_store_name); ?></h5>
                            </div>
                            <div class="py-2">
                                <h5>Receive Store - <?php echo e($inventory->receive_store_name); ?></h5>
                            </div>
                            <div class="py-2">
                                <h5>Status - <?php if($inventory->status==0): ?>
                                    <span class="text-warning">Pending</span>
                                <?php elseif($inventory->status==1): ?>
                                    <span class="text-success">Success</span>
                                <?php else: ?>
                                    <span class="text-danger">Reject</span>
                                <?php endif; ?></h5>
                            </div>
                            <div class="py-2 d-flex justify-content-end gap-1">
                                <div>
                                    <?php if($inventory->status==0): ?>
                                        <div class="dropdown">
                                            <button class="btn <?php if($inventory->status==0): ?> btn-warning  <?php elseif($inventory->status==1): ?> btn-success <?php elseif($inventory->status==2): ?> btn-danger <?php endif; ?> dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            <?php if($inventory->status==0): ?>
                                                Pending
                                            <?php elseif($inventory->status==1): ?>
                                                Success
                                            <?php elseif($inventory->status==2): ?>
                                                Reject
                                            <?php endif; ?>
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="<?php echo e(route('admin#inventoryChangeStatus',[$inventory->id,1])); ?>">Success</a></li>
                                                <li><a class="dropdown-item" href="<?php echo e(route('admin#inventoryChangeStatus',[$inventory->id,2])); ?>">Reject</a></li>
                                            </ul>
                                        </div>
                                    <?php elseif($inventory->status==1): ?>
                                        <button class="btn btn-outline-success">Success</button>
                                    <?php elseif($inventory->status==2): ?>
                                        <button class="btn btn-outline-danger">Reject</button>
                                    <?php endif; ?>

                                </div>
                                <?php if($inventory->status!=1): ?>
                                    <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#delete-inventory">Delete</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="delete-inventory" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="delete-inventoryLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title d-block w-100 text-center text-danger" id="delete-inventoryLabel">Delete Purchase</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('admin#inventoryDelete')); ?>" method="post" class="mt-1">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <div class="py-1">
                                <p class="text-danger">"Are you sure to delete this."</p>
                            </div>
                            <div class="py-1">
                                <h6>Verify you are admin. Please enter the password.</h6>
                            </div>
                            <div class="form-group mb-3">
                                <label class="mb-1">Password</label>
                                <input id="" name="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter your password." required>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <input type="hidden" name="id" value="<?php echo e($inventory->id); ?>">

                            <button type="submit" class="btn btn-danger w-100 my-2">Delete</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.admin.layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Main Project\TicketBookingSystem\ticket_booking_system\resources\views/main/admin/inventory/view.blade.php ENDPATH**/ ?>