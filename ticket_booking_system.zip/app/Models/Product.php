<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;
    protected $fillable=[
        'name',
        'description',
        'category_id',
        'cost_price',
        'selling_price',
        'instock',
        'profit_margin',
        'image',
        'active',
        'store_id',
    ];
}
